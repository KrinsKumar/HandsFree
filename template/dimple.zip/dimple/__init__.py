import streamlit.components.v1 as components

_component_func = components.declare_component("browser_transcribe", path="./frontend")

def browser_transcribe():
  value = _component_func()
  return value